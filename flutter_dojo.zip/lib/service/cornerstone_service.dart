import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter_dojo/model/cornerstone.dart';

class CornerstoneService {
  Future<List<Cornerstone>> getItems(BuildContext context) async {
    final jsonString = await DefaultAssetBundle.of(context)
        .loadString("lib/assets/json/cornerstones.json");

    final jsonMap = json.decode(jsonString).cast<Map<String, dynamic>>();

    return jsonMap
        .map<Cornerstone>((json) => Cornerstone.fromMap(json))
        .toList();
  }
}
