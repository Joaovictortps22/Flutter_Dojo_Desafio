import 'package:flutter/cupertino.dart';

const Color appPrimaryColor = const Color(0xff00aca6);
const Color appSecondaryColor = const Color(0xff592c82);
const Color appTertiaryColor = const Color(0xff3bb4e5);
