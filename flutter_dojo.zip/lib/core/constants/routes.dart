class Routes {
  static const String home = '/';
  static const String detail = '/detail';
}
