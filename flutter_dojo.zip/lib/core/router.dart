import 'package:flutter/material.dart';
import 'package:flutter_dojo/model/cornerstone.dart';
import 'package:flutter_dojo/screens/detail_screen.dart';
import 'package:flutter_dojo/screens/home_screen.dart';

import 'constants/routes.dart';

class Router {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case Routes.home:
        return MaterialPageRoute(builder: (_) => HomeScreen());
      case Routes.detail:
        return MaterialPageRoute(
          builder: (_) => DetailScreen(
            settings: (settings.arguments as Cornerstone),
          ),
        );
      //
      // To use in some widget:
      //
      // Navigator.pushNamed(context, Routes.details, arguments: cornerstone)
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text('Nenhuma rota definida para ${settings.name}.'),
            ),
          ),
        );
    }
  }
}
