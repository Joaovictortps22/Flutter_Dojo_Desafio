import 'package:flutter/material.dart';
import 'package:flutter_dojo/model/cornerstone.dart';

class DetailScreen extends StatelessWidget {
  final Cornerstone settings;

  const DetailScreen({Key key, this.settings}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),
    );
  }
}
