import 'package:flutter/material.dart';
import 'package:flutter_dojo/core/constants/colors.dart';
import 'package:flutter_dojo/model/cornerstone.dart';
import 'package:flutter_dojo/service/cornerstone_service.dart';
import 'package:flutter_dojo/widgets/icon_image.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: appPrimaryColor,
        title: Text("Nossos princípios"),
      ),
      body: FutureBuilder<List<Cornerstone>>(
          future: CornerstoneService().getItems(context),
          builder: (context, snapshot) {
            final List<Cornerstone> list = snapshot.data ?? List<Cornerstone>();

            return GridView.builder(
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
              itemCount: list.length,
              itemBuilder: (context, index) {
                final item = list.elementAt(index);

                return Card(
                  color: appSecondaryColor,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        IconImage(
                          identifier: item.icon,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Text(
                            item.title.toUpperCase(),
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                        ),
                        Text(
                          item.body,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            );
          }),
    );
  }
}
