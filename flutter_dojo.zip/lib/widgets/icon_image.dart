import 'package:flutter/material.dart';

class IconImage extends StatelessWidget {
  final String identifier;

  const IconImage({Key key, this.identifier}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Image.asset("lib/assets/icons/$identifier");
  }
}
