import 'package:flutter_dojo/model/cornerstone_detail.dart';

class Cornerstone {
  final String title;
  final String body;
  final String icon;
  final CornerstoneDetail detail;

  Cornerstone(this.title, this.body, this.icon, this.detail);

  static Cornerstone fromMap(Map map) {
    final title = map["title"] as String;
    final body = map["body"] as String;
    final icon = map["icon"] as String;
    final detailMap = map["detail"] as Map;
    final detail = CornerstoneDetail.fromMap(detailMap);

    return Cornerstone(title, body, icon, detail);
  }
}
