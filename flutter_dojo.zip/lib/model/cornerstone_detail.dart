class CornerstoneDetail {
  final String spotlight;
  final String message;

  CornerstoneDetail(this.spotlight, this.message);

  static CornerstoneDetail fromMap(Map map) {
    final spotlight = map["spotlight"] as String;
    final message = map["message"] as String;

    return CornerstoneDetail(spotlight, message);
  }
}
