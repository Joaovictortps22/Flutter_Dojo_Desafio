package com.example.flutter_dojo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
